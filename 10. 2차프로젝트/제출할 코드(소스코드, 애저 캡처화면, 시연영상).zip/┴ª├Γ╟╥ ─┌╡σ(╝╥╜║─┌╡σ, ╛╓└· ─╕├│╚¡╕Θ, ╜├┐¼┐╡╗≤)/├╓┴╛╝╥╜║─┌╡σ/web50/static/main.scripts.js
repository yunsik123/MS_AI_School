// 메인 페이지의 AI 버튼 클릭 시 Select 페이지로 이동
document.querySelector('.floating-button').addEventListener('click', function() {
  window.location.href = 'select.html'; // Select 페이지로 이동
});
