from azure.search.documents import SearchClient
from azure.core.credentials import AzureKeyCredential

def initialize_search_client():
    search_service_endpoint = "https://hani-search.search.windows.net"
    index_name = "hani-index"
    search_api_key = "0WFnq5l3cTRx7uQ4zwCqtyheHaPhfinc3piNAGx7yXAzSeCksTlN"

    search_client = SearchClient(
        endpoint=search_service_endpoint,
        index_name=index_name,
        credential=AzureKeyCredential(search_api_key)
    )
    return search_client

def search_documents(search_client, query):
    results = search_client.search(query)
    search_results = []
    max_results = 5  # 반환할 최대 검색 결과 수
    total_length = 0
    max_length = 10000  # 메시지에 포함될 최대 문자열 길이

    for i, result in enumerate(results):
        if i >= max_results:
            break

        content = result.get("content", str(result))
        content_length = len(content)

        if total_length + content_length > max_length:
            break

        search_results.append(content)
        total_length += content_length

    return "\n".join(search_results)



